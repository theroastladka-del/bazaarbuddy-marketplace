# BazaarBuddy Marketplace Starter (Hindi)

यह Expo/React Native का शुरुआती प्रोटोटाइप है। इसमें Customer, Seller, Delivery Boy और Admin के demo screens हैं। Product जोड़ना, cart, demo order और complaint flow केवल ऐप की memory में चलते हैं। ऐप बंद/reload करने पर data reset हो सकता है। इसमें अभी असली login/OTP, cloud database, payments, maps, role security या production-ready order handling नहीं है।

## सबसे आसान रास्ता (कंप्यूटर उपलब्ध हो तो)
1. Node.js का LTS version और Git install करें।
2. ZIP को extract करें और terminal/command prompt उस folder में खोलें।
3. चलाएँ: `npm install`
4. चलाएँ: `npx expo start`
5. फोन में Expo Go install करके terminal के QR code को scan करें (फोन और computer एक ही Wi-Fi पर हों)।

## APK बनाने का रास्ता
1. Expo account बनाएँ: https://expo.dev/
2. इस folder में terminal खोलें और चलाएँ: `npx eas-cli@latest login`
3. चलाएँ: `npx eas-cli@latest build:configure`
4. फिर चलाएँ: `npx eas-cli@latest build --platform android --profile preview`
5. पहली बार आने वाले prompts follow करें। Cloud build पूरा होने पर Expo build page से APK link मिलेगा। Free plan की limits बदल सकती हैं।

## अगला जरूरी चरण: Backend
Supabase पर project बनाकर Authentication, database tables, Storage और Row Level Security policies जोड़ें। किसी भी production table को public read/write न छोड़ें। Admin role को client-side toggle से secure नहीं माना जा सकता; role permissions server/database policies से enforce करनी होंगी। Payment gateway और SMS OTP provider अलग से configure होंगे।

Official guides:
- Expo: https://docs.expo.dev/
- EAS APK build: https://docs.expo.dev/build/setup/
- Supabase Expo quickstart: https://supabase.com/docs/guides/getting-started/quickstarts/expo-react-native
