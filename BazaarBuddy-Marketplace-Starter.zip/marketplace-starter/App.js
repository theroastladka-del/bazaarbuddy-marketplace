import React, { useMemo, useState } from 'react';
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, Alert } from 'react-native';

const START_PRODUCTS = [
  { id: 'p1', name: 'Cotton T-Shirt', category: 'Clothing', price: 299, seller: 'Demo Seller', stock: 12 },
  { id: 'p2', name: 'Water Bottle', category: 'Home', price: 149, seller: 'Demo Seller', stock: 20 },
  { id: 'p3', name: 'Wireless Earphones', category: 'Electronics', price: 799, seller: 'Demo Seller', stock: 5 },
];
const ROLES = [
  { id: 'customer', title: 'Customer', subtitle: 'Browse and order products' },
  { id: 'seller', title: 'Seller', subtitle: 'List products and manage orders' },
  { id: 'delivery', title: 'Delivery Boy', subtitle: 'View assigned deliveries' },
  { id: 'admin', title: 'Admin', subtitle: 'Manage demo marketplace' },
];
const money = (n) => `₹${Number(n).toLocaleString('en-IN')}`;

export default function App() {
  const [role, setRole] = useState('customer');
  const [products, setProducts] = useState(START_PRODUCTS);
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [stock, setStock] = useState('1');
  const [search, setSearch] = useState('');
  const [complaints, setComplaints] = useState([]);
  const [complaintText, setComplaintText] = useState('');
  const [tab, setTab] = useState('home');

  const filteredProducts = useMemo(() => products.filter(p => `${p.name} ${p.category}`.toLowerCase().includes(search.toLowerCase())), [products, search]);
  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  const addToCart = (product) => setCart(old => {
    const found = old.find(i => i.id === product.id);
    if (found) return old.map(i => i.id === product.id ? { ...i, qty: i.qty + 1 } : i);
    return [...old, { ...product, qty: 1 }];
  });
  const placeOrder = () => {
    if (!cart.length) return Alert.alert('Cart is empty', 'Add a product first.');
    const order = { id: `ORD-${Date.now().toString().slice(-6)}`, items: cart, total: cartTotal, status: 'Order Placed', customer: 'Demo Customer' };
    setOrders(old => [order, ...old]); setCart([]); setTab('orders');
    Alert.alert('Demo order placed', `Your order ${order.id} has been created on this device.`);
  };
  const addProduct = () => {
    const numericPrice = Number(price), numericStock = Number(stock);
    if (!name.trim() || !Number.isFinite(numericPrice) || numericPrice <= 0 || !Number.isInteger(numericStock) || numericStock < 0) {
      return Alert.alert('Check details', 'Enter a product name, valid price and whole-number stock.');
    }
    setProducts(old => [{ id: `p${Date.now()}`, name: name.trim(), category: 'Seller Listing', price: numericPrice, seller: 'Your Demo Shop', stock: numericStock }, ...old]);
    setName(''); setPrice(''); setStock('1');
    Alert.alert('Added in demo', 'This product is saved only in the current app session, not online.');
  };
  const addComplaint = () => {
    if (!complaintText.trim()) return Alert.alert('Enter complaint', 'Write a short description first.');
    setComplaints(old => [{ id: `CMP-${Date.now().toString().slice(-5)}`, text: complaintText.trim(), status: 'Open' }, ...old]);
    setComplaintText(''); Alert.alert('Demo complaint added', 'It is visible in the Admin demo panel on this device.');
  };
  const updateOrder = (id, status) => setOrders(old => old.map(o => o.id === id ? { ...o, status } : o));

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <View><Text style={styles.brand}>BazaarBuddy</Text><Text style={styles.tagline}>Your local marketplace · Starter demo</Text></View>
        <Text style={styles.roleBadge}>{ROLES.find(r => r.id === role)?.title}</Text>
      </View>
      <View style={styles.roleRow}>
        {ROLES.map(r => <TouchableOpacity key={r.id} onPress={() => { setRole(r.id); setTab(r.id === 'customer' ? 'home' : r.id === 'seller' ? 'seller' : r.id === 'delivery' ? 'delivery' : 'admin'); }} style={[styles.roleButton, role === r.id && styles.roleSelected]}><Text style={[styles.roleButtonText, role === r.id && styles.roleSelectedText]}>{r.title}</Text></TouchableOpacity>)}
      </View>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {role === 'customer' && <>
          <Text style={styles.title}>Find your next favourite</Text><Text style={styles.muted}>Demo products — not a live store yet.</Text>
          <TextInput value={search} onChangeText={setSearch} placeholder="Search products..." placeholderTextColor="#8993a4" style={styles.input}/>
          <View style={styles.rowBetween}><Text style={styles.sectionTitle}>Products ({filteredProducts.length})</Text><Text style={styles.muted}>Cart: {cart.reduce((s,i)=>s+i.qty,0)} item(s)</Text></View>
          {filteredProducts.map(p => <View key={p.id} style={styles.productCard}><View style={styles.productIcon}><Text style={styles.productEmoji}>▣</Text></View><View style={styles.productInfo}><Text style={styles.productName}>{p.name}</Text><Text style={styles.muted}>{p.category} · {p.stock} in stock</Text><Text style={styles.price}>{money(p.price)}</Text><Text style={styles.smallMuted}>Sold by {p.seller}</Text></View><TouchableOpacity style={styles.primarySmall} onPress={() => addToCart(p)}><Text style={styles.primaryText}>+ Add</Text></TouchableOpacity></View>)}
          <Text style={styles.sectionTitle}>Your Cart</Text>
          {cart.length === 0 ? <Text style={styles.empty}>Your cart is empty.</Text> : cart.map(i => <Text key={i.id} style={styles.listLine}>{i.name} × {i.qty} — {money(i.price * i.qty)}</Text>)}
          <View style={styles.rowBetween}><Text style={styles.total}>Total: {money(cartTotal)}</Text><TouchableOpacity style={styles.primary} onPress={placeOrder}><Text style={styles.primaryText}>Place demo order</Text></TouchableOpacity></View>
          <Text style={styles.sectionTitle}>Need help?</Text><TextInput value={complaintText} onChangeText={setComplaintText} placeholder="Write a complaint or question..." placeholderTextColor="#8993a4" style={styles.input}/><TouchableOpacity style={styles.secondary} onPress={addComplaint}><Text style={styles.secondaryText}>Submit demo complaint</Text></TouchableOpacity>
          <Text style={styles.sectionTitle}>Recent Orders</Text>{orders.length === 0 ? <Text style={styles.empty}>No orders yet.</Text> : orders.map(o => <OrderCard key={o.id} order={o}/>) }
        </>}
        {role === 'seller' && <>
          <Text style={styles.title}>Seller Dashboard</Text><Text style={styles.muted}>Add products to this local demo catalogue.</Text>
          <Text style={styles.label}>Product name</Text><TextInput value={name} onChangeText={setName} placeholder="e.g. Blue shirt" placeholderTextColor="#8993a4" style={styles.input}/>
          <Text style={styles.label}>Price (₹)</Text><TextInput value={price} onChangeText={setPrice} keyboardType="decimal-pad" placeholder="e.g. 499" placeholderTextColor="#8993a4" style={styles.input}/>
          <Text style={styles.label}>Stock quantity</Text><TextInput value={stock} onChangeText={setStock} keyboardType="number-pad" placeholder="e.g. 10" placeholderTextColor="#8993a4" style={styles.input}/>
          <TouchableOpacity style={styles.primary} onPress={addProduct}><Text style={styles.primaryText}>Add Product</Text></TouchableOpacity>
          <Text style={styles.sectionTitle}>My Listings (demo)</Text>{products.filter(p => p.seller === 'Your Demo Shop').map(p => <Text key={p.id} style={styles.listLine}>{p.name} · {money(p.price)} · Stock {p.stock}</Text>)}
          <Text style={styles.sectionTitle}>Orders to review</Text>{orders.length === 0 ? <Text style={styles.empty}>No orders yet.</Text> : orders.map(o => <OrderCard key={o.id} order={o}/>) }
        </>}
        {role === 'delivery' && <>
          <Text style={styles.title}>Delivery Dashboard</Text><Text style={styles.muted}>This demo shows all created orders. A live version must show only orders assigned to the signed-in delivery person.</Text>
          {orders.length === 0 ? <Text style={styles.empty}>No delivery orders yet. Place a demo order as Customer first.</Text> : orders.map(o => <View key={o.id} style={styles.card}><Text style={styles.productName}>{o.id}</Text><Text style={styles.listLine}>Amount: {money(o.total)}</Text><Text style={styles.muted}>Status: {o.status}</Text><View style={styles.actionRow}><TouchableOpacity style={styles.secondary} onPress={() => updateOrder(o.id, 'Picked Up')}><Text style={styles.secondaryText}>Mark Picked Up</Text></TouchableOpacity><TouchableOpacity style={styles.primarySmall} onPress={() => updateOrder(o.id, 'Delivered (demo)')}><Text style={styles.primaryText}>Delivered</Text></TouchableOpacity></View></View>)}
        </>}
        {role === 'admin' && <>
          <Text style={styles.title}>Admin Overview</Text><Text style={styles.muted}>Demo control panel — no real accounts or online records yet.</Text>
          <View style={styles.statsGrid}><Stat label="Products" value={products.length}/><Stat label="Orders" value={orders.length}/><Stat label="Complaints" value={complaints.length}/><Stat label="Demo sales" value={money(orders.reduce((s,o)=>s+o.total,0))}/></View>
          <Text style={styles.sectionTitle}>Manage Orders</Text>{orders.length === 0 ? <Text style={styles.empty}>No orders yet.</Text> : orders.map(o => <View key={o.id} style={styles.card}><Text style={styles.productName}>{o.id}</Text><Text style={styles.listLine}>{money(o.total)} · {o.items.map(i=>`${i.name} ×${i.qty}`).join(', ')}</Text><Text style={styles.muted}>Status: {o.status}</Text><View style={styles.actionRow}><TouchableOpacity style={styles.secondary} onPress={() => updateOrder(o.id, 'Confirmed')}><Text style={styles.secondaryText}>Confirm</Text></TouchableOpacity><TouchableOpacity style={styles.secondary} onPress={() => updateOrder(o.id, 'Cancelled')}><Text style={styles.secondaryText}>Cancel</Text></TouchableOpacity></View></View>)}
          <Text style={styles.sectionTitle}>Complaints</Text>{complaints.length === 0 ? <Text style={styles.empty}>No demo complaints.</Text> : complaints.map(c => <View key={c.id} style={styles.card}><Text style={styles.productName}>{c.id}</Text><Text style={styles.listLine}>{c.text}</Text><Text style={styles.muted}>Status: {c.status}</Text><TouchableOpacity style={styles.primarySmall} onPress={() => setComplaints(old => old.map(x => x.id === c.id ? {...x, status: 'Resolved (demo)'} : x))}><Text style={styles.primaryText}>Mark Resolved</Text></TouchableOpacity></View>)}
          <Text style={styles.sectionTitle}>Products</Text>{products.map(p => <Text key={p.id} style={styles.listLine}>{p.name} · {money(p.price)} · {p.seller}</Text>)}
        </>}
        <View style={styles.notice}><Text style={styles.noticeTitle}>Important before real launch</Text><Text style={styles.noticeText}>This is a starter prototype. Data is stored only in app memory and resets when the app restarts. There is no real login, OTP, online database, payment, map, or secure role control yet. Do not use it for real customer orders until backend security and payments are implemented and tested.</Text></View>
      </ScrollView>
      <View style={styles.footer}><Text style={styles.footerText}>BazaarBuddy · Marketplace starter · v0.1</Text></View>
    </SafeAreaView>
  );
}
function OrderCard({ order }) { return <View style={styles.card}><Text style={styles.productName}>{order.id}</Text><Text style={styles.listLine}>{order.items.map(i=>`${i.name} ×${i.qty}`).join(', ')}</Text><Text style={styles.price}>{money(order.total)}</Text><Text style={styles.muted}>Status: {order.status}</Text></View>; }
function Stat({label,value}) { return <View style={styles.stat}><Text style={styles.statValue}>{value}</Text><Text style={styles.muted}>{label}</Text></View>; }
const styles = StyleSheet.create({safe:{flex:1,backgroundColor:'#f5f7fb'},header:{paddingHorizontal:18,paddingTop:12,paddingBottom:14,flexDirection:'row',justifyContent:'space-between',alignItems:'center',backgroundColor:'#fff'},brand:{fontSize:23,fontWeight:'900',color:'#16233a'},tagline:{fontSize:11,color:'#68758a',marginTop:3},roleBadge:{backgroundColor:'#e9f1ff',color:'#2354b4',paddingHorizontal:10,paddingVertical:7,borderRadius:14,fontSize:11,fontWeight:'800'},roleRow:{flexDirection:'row',flexWrap:'wrap',paddingHorizontal:10,paddingVertical:9,gap:6,backgroundColor:'#fff',borderTopWidth:1,borderTopColor:'#edf0f5'},roleButton:{paddingHorizontal:11,paddingVertical:9,borderRadius:10,borderWidth:1,borderColor:'#dce2ec'},roleSelected:{backgroundColor:'#2057c7',borderColor:'#2057c7'},roleButtonText:{fontSize:11,fontWeight:'700',color:'#3b4659'},roleSelectedText:{color:'#fff'},content:{padding:16,paddingBottom:32},title:{fontSize:24,fontWeight:'900',color:'#18243a',marginBottom:5},muted:{fontSize:12,color:'#748096',lineHeight:18},smallMuted:{fontSize:11,color:'#7d8798',marginTop:3},sectionTitle:{fontSize:17,fontWeight:'800',color:'#202d43',marginTop:22,marginBottom:10},input:{backgroundColor:'#fff',borderWidth:1,borderColor:'#dce2ec',borderRadius:12,paddingHorizontal:13,paddingVertical:12,fontSize:14,color:'#172033',marginTop:8,marginBottom:12},label:{fontSize:12,fontWeight:'700',color:'#4c586b',marginTop:7},rowBetween:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginTop:14},productCard:{flexDirection:'row',alignItems:'center',backgroundColor:'#fff',borderRadius:15,padding:12,marginTop:10,borderWidth:1,borderColor:'#edf0f5'},productIcon:{width:48,height:48,borderRadius:12,backgroundColor:'#edf3ff',alignItems:'center',justifyContent:'center',marginRight:11},productEmoji:{fontSize:25,color:'#2c5dc1'},productInfo:{flex:1},productName:{fontSize:14,fontWeight:'800',color:'#202c40',marginBottom:4},price:{fontSize:16,fontWeight:'900',color:'#145c3b',marginTop:4},primary:{backgroundColor:'#2057c7',paddingHorizontal:15,paddingVertical:12,borderRadius:12,alignItems:'center',justifyContent:'center'},primarySmall:{backgroundColor:'#2057c7',paddingHorizontal:12,paddingVertical:10,borderRadius:10,alignItems:'center',justifyContent:'center'},primaryText:{color:'#fff',fontSize:12,fontWeight:'800'},secondary:{backgroundColor:'#eef3fb',paddingHorizontal:12,paddingVertical:10,borderRadius:10,alignItems:'center',justifyContent:'center'},secondaryText:{color:'#254a8b',fontSize:12,fontWeight:'800'},empty:{color:'#7c8799',fontSize:13,backgroundColor:'#fff',padding:14,borderRadius:12},listLine:{fontSize:13,color:'#455167',lineHeight:21,marginTop:5},total:{fontSize:16,fontWeight:'900',color:'#202c40'},card:{backgroundColor:'#fff',padding:14,borderRadius:14,marginTop:10,borderWidth:1,borderColor:'#e9edf4'},actionRow:{flexDirection:'row',gap:8,marginTop:12,flexWrap:'wrap'},statsGrid:{flexDirection:'row',flexWrap:'wrap',gap:10,marginTop:15},stat:{width:'47%',backgroundColor:'#fff',borderRadius:14,padding:14,borderWidth:1,borderColor:'#e9edf4'},statValue:{fontSize:21,fontWeight:'900',color:'#1d4da7',marginBottom:5},notice:{backgroundColor:'#fff7e8',borderColor:'#f5dfb2',borderWidth:1,borderRadius:13,padding:13,marginTop:24},noticeTitle:{fontSize:13,fontWeight:'900',color:'#79510b',marginBottom:5},noticeText:{fontSize:12,lineHeight:18,color:'#755d32'},footer:{padding:10,alignItems:'center',backgroundColor:'#fff',borderTopWidth:1,borderTopColor:'#e9edf4'},footerText:{fontSize:10,color:'#8b95a5'}});
